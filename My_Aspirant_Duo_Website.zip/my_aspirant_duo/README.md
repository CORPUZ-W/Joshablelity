# My Aspirant Duo

A small static website made for GitHub Pages.

## Preview on your phone or computer
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and the entire `assets` folder (keep the folder name `assets`).
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site.

## Optional background music
The site does not include copyrighted Aspirants soundtrack audio. To play a soundtrack, use the **Add music** button on the website and choose an audio file from your device. The file is played locally in that browser session and is not uploaded by the site.

## Privacy note
If the GitHub repository is public, anyone with the site URL may be able to view the photos and letter. Only upload pictures and details you are comfortable sharing. A private repository does not automatically make a GitHub Pages website private.
